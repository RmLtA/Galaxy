﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PROJECTUML
{
    public class OrcUnitImpl : UnitImpl, OrcUnit
    {
        public OrcUnitImpl()
        {
            throw new System.NotImplementedException();
        }
    }

    public interface OrcUnit : Unit
    {
    }
}
