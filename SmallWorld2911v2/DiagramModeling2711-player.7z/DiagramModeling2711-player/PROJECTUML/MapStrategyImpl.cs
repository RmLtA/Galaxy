﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PROJECTUML
{
    public  abstract class StrategyImpl : Strategy
    {
        //protected int TurnNumber;
        //protected int UnitNumber;
    
        public Map execute()
        {
            throw new NotImplementedException();
        }
    }
}
