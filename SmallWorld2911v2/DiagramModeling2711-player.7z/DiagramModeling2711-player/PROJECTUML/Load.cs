﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PROJECTUML
{
    public class LoadGamePlayImpl : GamePlayBuilderImpl, LoadGamePlay
    {
        public GamePlay start(Player p1, Player p2)
        {
            throw new System.NotImplementedException();
        }

        public void fillInSquare()
        {
            throw new System.NotImplementedException();
        }
    }
}
