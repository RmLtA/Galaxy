﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PROJECTUML
{
    public class ElfUnitImpl : UnitImpl, ElfUnit
    {
        public ElfUnitImpl()
        {
            
        }
    }

    public interface ElfUnit : Unit
    {
    }
}
